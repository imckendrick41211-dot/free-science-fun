# Tactical FPS Multiplayer — Setup Guide

This package contains the HTML game configured for the browser-based multiplayer prototype. It is designed for up to four players using room codes and includes the game's existing offline and Geometry Dash modes.

## Files

- `index.html` — complete game file to publish.
- `README.md` — these setup instructions.

## Publish without installing software

1. Download and extract this ZIP archive.
2. Sign in to [GitHub](https://github.com/) and create a **public** repository, for example `my-fps-game`.
3. Upload `index.html` to the root of the repository.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and the `/ (root)` folder, then save.
7. Wait for GitHub Pages to publish the site, then open the URL it provides.

## Try a multiplayer room

1. Open the published site.
2. Select **Create Room** and share the site URL and room code with up to three friends.
3. Friends open the same URL, enter the code, and select **Join Room**.
4. Keep the room host's browser tab open during the session.

## Important limitations

GitHub Pages only hosts the static webpage; it does not run a multiplayer server. This prototype relies on PeerJS's hosted signalling service and browser-to-browser connections. Connectivity may depend on network/firewall conditions and the external service's availability. The host's browser is not a dedicated authoritative server, so this prototype is not cheat-resistant. The multiplayer implementation has not been verified in a live four-device test; test room creation, joining, health, damage, respawning, and score synchronization before relying on it.

If room connections fail, confirm the page is loaded over HTTPS, that all players use the same published URL, and that the signalling service is reachable. Do not share private credentials in a public repository.
